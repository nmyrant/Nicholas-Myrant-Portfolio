
public class manager extends employee {

	public void setDepartment(String newDepartment) {
		department = newDepartment;

	}

	public String getDepartment() {
		return department;
	}

	public void employeeSummary() {
		super.employeeSummary(); // added super.employeeSummary
		System.out.println("Department: " + department);
	}

	private String department;
}