

       	public class EmployeeInheritance{
			public static void main(String[] args) {
				 
				employee Dan = new employee();
				manager Dave = new manager();
				
				
				Dan.setFirst("Dan");
				Dan.setLast("Rogers");
				Dan.setEid(818469);
				Dan.setSalary(40000.0);
				Dan.employeeSummary();
				
				System.out.println("");
				
				Dave.setFirst("Dave");
				Dave.setLast("Smith");
				Dave.setEid(393109);
				Dave.setSalary(75000.0);
				Dave.setDepartment("Legal");
				Dave.employeeSummary();
				
				
			}	
			
		}  