import java.util.ArrayList;

public class MergeSort {
   public static void merge(ArrayList<Student> list, int i, int j, int k) {
     
	   RollnoComparitor c1 = new RollnoComparitor();                     // Creates an object c1 of type RollnoComparitor
	   
	  int mergedSize = k - i + 1;       // Size of merged partition
	  ArrayList<Student> tempList = new ArrayList<Student>(mergedSize);  // Temporary array list for merged numbers
	  for (int x = 0; x < mergedSize; x++) {                             // Allocates empty space for the temp list
		   tempList.add(null);									         // to avoid index out of bounds error
		}
	  
	  int mergePos;                    									 // Position to insert merged number
      int leftPos;                   								     // Position of elements in left partition
      int rightPos;                  								    // Position of elements in right partition

      mergePos = 0;
      leftPos = i;                      								// Initialize left partition position
      rightPos = j + 1;                 								// Initialize right partition position

      // Add smallest element from left or right partition to merged numbers
      while (leftPos <= j && rightPos <= k) {   
         if (c1.compare(list.get(leftPos), list.get(rightPos)) < 0) {
        	 tempList.set(mergePos, list.get(leftPos));
            ++leftPos;
         } 
         else { 	 
        	 tempList.set(mergePos, list.get(rightPos));
            ++rightPos;   
         }
         ++mergePos;
      }
      // If left partition is not empty, add remaining elements to merged numbers
      while (leftPos <= j) {	  
    	  tempList.set(mergePos, list.get(leftPos));
         ++leftPos;
         ++mergePos;
      }

      // If right partition is not empty, add remaining elements to merged numbers
      while (rightPos <= k) {  
    	  tempList.set(mergePos, list.get(rightPos));
         ++rightPos;
         ++mergePos;
      }

      // Copy merge number back to numbers     
      for (mergePos = 0; mergePos < mergedSize; ++mergePos) {  
    	  list.set(i + mergePos, tempList.get(mergePos));   
      }
   }

   public static void mergeSort(ArrayList<Student> list, int i, int k) {
      int j;

      if (i < k) {
         j = (i + k) / 2;  // Find the midpoint in the partition

         // Recursively sort left and right partitions
         mergeSort(list, i, j);
         mergeSort(list, j + 1, k);

         // Merge left and right partition in sorted order
         merge(list, i, j, k);
      }
   }
   
}