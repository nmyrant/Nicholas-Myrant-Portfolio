import java.util.ArrayList;

public class StudentSorter extends MergeSort {
	public static void main(String[] args) {
		// Creates array list sArray of type student
		ArrayList<Student> sArray = new ArrayList<Student>();
		
		// Fills the array list with 10 students 
		sArray.add(new Student(4002, "Brian", "4th street"));
		sArray.add(new Student(1426, "Bobby", "1st street"));
		sArray.add(new Student(9999, "Phil", "10th street"));
		sArray.add(new Student(9292, "Lucas", "9th street"));
		sArray.add(new Student(5252, "Nick", "5th street"));
		sArray.add(new Student(8643, "Katie", "8th street"));
		sArray.add(new Student(7716, "Bruce", "7th street"));
		sArray.add(new Student(6790, "Ashley", "6th street"));
		sArray.add(new Student(3779, "James", "3rd street"));
		sArray.add(new Student(2326, "Sarah", "2nd street"));
		
		
		// Prints the unsorted array list
		System.out.println("UNSORTED:");
		for (Student student : sArray) {
			student.printInfo();
		}
			
		// Sorts the array list by rollno using mergeSort
		mergeSort(sArray, 0, sArray.size()-1);
		
		
		// Prints the now sorted array list, sorted by rollno
		System.out.println("\nSORTED BY ROLL NUMBER:");
		for (Student student : sArray) {
			student.printInfo();
		}
		
	}

}
