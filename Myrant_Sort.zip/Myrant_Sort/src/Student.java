public class Student {

	Integer rollno;
	String name;
	String address;
	
	// Constructor 
	Student(int rollno, String name, String address){	
		this.rollno = rollno;
		this.name = name;
		this.address = address;
	}
	// Method to print all attributes for a student
	public void printInfo() {
		System.out.println("Roll #: " + rollno + ". "
					     + "Name: " + name + ". " 
						 +"Address: " + address + ".");
	}
}