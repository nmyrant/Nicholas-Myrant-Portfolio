package application;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.application.Platform;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

public class timeLog extends Application {
	
	// Method for generating random orange color made
	// as a separate object so it can be called for the
	// button press as well as to start random
	public String randOrange() {
	      Random random = new Random();
		  int red = random.nextInt(156) + 100;  
	      int green = random.nextInt(128 - red/2) + red/2;  
	      int blue = 0;
		  String randomOrange = String.format("#%02X%02X%02X", red, green, blue);   
		  return randomOrange;
	     }
   
   @Override
   public void start(Stage applicationStage) {
      
      GridPane gridPane = new GridPane();   // Create an empty pane
      Scene scene = new Scene(gridPane);    // Create scene containing the grid pane
      
      
      
     Label dateLabel = new Label("Current date & time: ");
      
     TextField dateField = new TextField(); 
      dateField.setPrefColumnCount(15);
      dateField.setEditable(false);
      
    // Creates buttons for each of the 4 functions  
    Button button1 = new Button("Get Date & Time");
    Button button2 = new Button("Log");
    Button button3 = new Button("Frame Color");
    Button button4 = new Button("Exit");
    
      
      gridPane.setPadding(new Insets(10, 10, 10, 10)); // Padding around  grid
      gridPane.setHgap(10);                            // Spacing between columns
      gridPane.setVgap(10);                            // Spacing between rows
      
      gridPane.add(button1, 0, 0);  				   // Adds buttons for each of the 4 functions on top
      gridPane.add(button2, 1, 0);  
      gridPane.add(button3, 2, 0);   
      gridPane.add(button4, 3, 0);  
      gridPane.add(dateLabel, 0, 1);				  // Adds the dateLabel and dateField to display data
      gridPane.add(dateField, 1, 1, 3, 1);    		  // Made dateField take up multiple columns to 
      												  // everything fits better

      // Set an event handler to show the current date and time in the text field
      // on each button press
      button1.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent event) {
        	 Date date = new Date();
        	 SimpleDateFormat dateFor = new SimpleDateFormat("dd-MM-yyy hh:mm:ss");
        	 String strDateTime = dateFor.format(date);
        	dateField.setText(strDateTime);
         } 
      });
      
   // Set an event handler to write to log.txt and replace text field
   // with "Date and time logged." Every time button2 is pressed. Will 
   //   print an error if failed to write.
      button2.setOnAction(new EventHandler<ActionEvent>() {
          @Override
          public void handle(ActionEvent event) {
        	  
        	//tries to pull from the datefield and write to log.txt  
        	try { 
        
        	  String dateTime = dateField.getText();	  
        	  FileWriter fileWriter = new FileWriter("log.txt", true);
        	  fileWriter.write(dateTime + "\n");
        	  fileWriter.close();
        	 
        	// Sets the text in the date field to indicate it was logged  
         	 dateField.setText("Date and time logged.");
        	}
        	
        	// if it fails it is "caught" and an error message is shown
        	catch (IOException e) {
        		System.out.println("Failed to write to file");	
        	} 	 
          } 
       });
      
   // Set an event handler to randomly change frame color when button3 pressed
   // to random shade of orange
      button3.setOnAction(new EventHandler<ActionEvent>() {
          @Override
          public void handle(ActionEvent event) {
        	  String color = randOrange();
        	  gridPane.setStyle("-fx-background-color: " + color);
          } 
       });
      
   // Set an event handler to exit when button4 pressed
      button4.setOnAction(new EventHandler<ActionEvent>() {
          @Override
          public void handle(ActionEvent event) {
         	Platform.exit();
          } 
       });
      
    //Starts the program on a random color of orange
      String color = randOrange();
	  gridPane.setStyle("-fx-background-color: " + color);
      
      applicationStage.setScene(scene);    // Set window's scene  
      applicationStage.setTitle("Time Log"); // Set window's title
      applicationStage.show();             // Display window

   }
   
   public static void main(String [] args) {
      launch(args); // Launch application
   }
}