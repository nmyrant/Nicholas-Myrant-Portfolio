    import java.awt.GridBagConstraints;
	import java.awt.GridBagLayout;
	import java.awt.Insets;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JTextField;
	import javax.swing.JOptionPane;
	import java.time.LocalDate;
    import java.time.Period;  

	public class AgeCalculator extends JFrame implements ActionListener {
	   private JLabel birthLabel;      // Label birthday
	   private JLabel ageLabel;        // Label for age
	   private JTextField birthField;  // Displays birthday 
	   private JTextField ageField;    // Displays age
	   private JButton birthdayButton; //Triggers age calculation
	   LocalDate todaysDate = LocalDate.now();

	   /* Constructor creates GUI components and adds GUI components
	      using a GridBagLayout. */
	   AgeCalculator() {
	      // Used to specify GUI component layout
	      GridBagConstraints layoutConst = null;

	      // Set frame's title
	      setTitle("Age Calculator");
	      
	      // Labels
	      birthLabel = new JLabel("Enter your birthday in YYYY-MM-DD format:");
	      ageLabel = new JLabel("Your age is:");

	      // Set hourly and yearly salary
	      ageField = new JTextField(25);
	      ageField.setEditable(true);
	      ageField.setText("");
	      ageField.addActionListener(this);

	      birthField = new JTextField(25);
	      birthField.setEditable(false);
	      
	      // Creates a button to calculate users age
	      birthdayButton = new JButton ("Calculate Age");
	      // Uses "this" for button press
	      birthdayButton.addActionListener(this);

	      setLayout(new GridBagLayout());
	      layoutConst = new GridBagConstraints();
	      layoutConst.gridx = 0;
	      layoutConst.gridy = 0;
	      layoutConst.insets = new Insets(15, 25, 10, 10);
	      add(birthLabel, layoutConst);

	      layoutConst = new GridBagConstraints();
	      layoutConst.gridx = 1;
	      layoutConst.gridy = 0;
	      layoutConst.insets = new Insets(15, 0, 10, 20);
	      add(ageField,  layoutConst);
	      

	      layoutConst = new GridBagConstraints();
	      layoutConst.gridx = 0;
	      layoutConst.gridy = 1;
	      layoutConst.insets = new Insets(10, 0, 20, 10);
	      add(birthdayButton, layoutConst);
	      
	      
	      layoutConst = new GridBagConstraints();
	      layoutConst.gridx = 0;
	      layoutConst.gridy = 1;
	      layoutConst.insets = new Insets(10, 200, 20, 10);
	      add(ageLabel, layoutConst);
	      
	      
	      layoutConst = new GridBagConstraints();
	      layoutConst.gridx = 1;
	      layoutConst.gridy = 1;
	      layoutConst.insets = new Insets(10, 0, 20, 20);
	      add(birthField, layoutConst);
	    
	   }

	   @Override
	   public void actionPerformed(ActionEvent event) {
	      String userInput;     
	      LocalDate birthday = LocalDate.now();   
	      int years = 0;
	      int months = 0;
	      int days = 0;
	      boolean dateGood = false;

	      // Get user's birthday input
	      userInput = ageField.getText();
	      
	      // Tries to convert from a String to a LocalDate
	      try {
	    	  birthday = LocalDate.parse(userInput);
	    	  dateGood = true;
	      }
	      
	      // Error message for invalid input 
	      catch(Exception e) {
	    	  JOptionPane.showMessageDialog(this, "Please use the YYYY-MM-DD format.");	
	    	  dateGood = false;
	      }
	      
	      if (dateGood){  
	    	  
	      // Gets the time between the years, months, and days
	      Period time = Period.between(birthday, todaysDate);
	      years = time.getYears(); 
	      months = time.getMonths(); 
	      days = time.getDays();
	      }
	      
	      // Resets text field to blank text on invalid input
	      else {
	    	  birthField.setText(" ");
	          }
	      
	      
	    if (days > 0)	 {
	      // Display calculated age
	      birthField.setText("Your age is " + years + " years " + months + " month(s) " + " and " + days + " days.");
	      
	      }
	    else if (days == 0) {
	    	JOptionPane.showMessageDialog(this, "You were born today! Impressive you are already using a keyboard.");	
	    	birthField.setText(" ");
	     }
	    else if (days < 0) {
	    	JOptionPane.showMessageDialog(this, "That day hasn't happened yet! Try again.");
	    	birthField.setText(" ");
	    }
	      
	   }
	      
	    
	   // Creates a SalaryCalculatorFrame and makes it visible 
	   public static void main(String[] args) {
	      // Creates SalaryLabelFrame and its components
		   AgeCalculator myFrame = new AgeCalculator();

	      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      myFrame.pack();
	      myFrame.setVisible(true);
	   }
	}		
	