
public class UserInfo {

	public static void main(String[] args) {

		// print lines for each bit of required information
		System.out.println("First Name: John");
		System.out.println("Last Name: Doe");
		System.out.println("Street Address: 1234 Generic Street");
		System.out.println("City: Happy Town");
		System.out.println("Zip Code: 123456");

	}
}
