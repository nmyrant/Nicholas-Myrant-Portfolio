
public final class ShoppingCart<T> implements BagInterface<T> {

	private final T[] bag;
	private int numberOfProducts;
	private boolean integrityOK;
	private static final int DEFAULT_CAPACITY = 25;
	private static final int MAX_CAPACITY = 10000;
	
private void checkIntegrity() {
	if(!integrityOK)
		throw new SecurityException("Shopping Cart object is corrupt.");
}

public ShoppingCart() {
	this(DEFAULT_CAPACITY);
}

public ShoppingCart(int desiredCapacity) {
	integrityOK = false;
	if (desiredCapacity <= MAX_CAPACITY) {
		@SuppressWarnings("unchecked")
		T[] tempBag = (T[])new Object[desiredCapacity];
		bag = tempBag;
		numberOfProducts = 0;
		integrityOK = true;		
	}
	else
		throw new IllegalStateException("Attempt to create a bag whose " +
										"capacity exceeds allowed maximum.");
}

public boolean add(T newEntry) {
	checkIntegrity();
	boolean result = true;
	if (isFull()) {
		result = false;
	}
	else {
		bag[numberOfProducts] = newEntry;
		numberOfProducts++;
	}
	return result;	
}

private boolean isFull() {
	return numberOfProducts >=bag.length;
}

public T[] toArray(){
	checkIntegrity();
	@SuppressWarnings("unchecked")
	T[] result = (T[]) new Object[numberOfProducts];
	for(int i = 0; i < numberOfProducts; i++) {
		result[i] = bag[i];
	}
	return result;
}

public int getCurrentSize() { 
	return numberOfProducts;
}
	
public boolean isEmpty() {
	return numberOfProducts == 0;
}

public int getFrequencyOf(T anEntry) {
	checkIntegrity();
	int counter = 0;
	for (int i = 0; i <numberOfProducts; i++) {
		if (anEntry.equals(bag[i])) {
		counter++;
		}
	}
	return counter;
}

public boolean contains(T anEntry) {
	checkIntegrity();
	return getIndexOf(anEntry) > -1;
}

public void clear() {
	while (!isEmpty())
		remove();
}

public T remove() {
	checkIntegrity();
	T result = null;
	if (numberOfProducts > 0) {
		result = bag[numberOfProducts - 1];
		bag[numberOfProducts-1] = null;
		numberOfProducts--;
		}
	return result;
}

private int getIndexOf (T anEntry) {
	int where = -1;
	boolean found = false;
	int i = 0;
		while(!found && (i < numberOfProducts)) {
			if (anEntry.equals(bag[i])) {
				found = true;
				where = i;
			}
			else i++;
		}
	return where;
}

private T removeEntry(int givenIndex) {
	T result = null;
	if (!isEmpty() && (givenIndex >= 0)) {
		result = bag [givenIndex];
		bag[givenIndex] = bag[numberOfProducts -1];
		bag[numberOfProducts -1] = null;
		numberOfProducts--;
	}
	return result;
}
	
public boolean remove (T anEntry) {
	checkIntegrity();
	int i = getIndexOf(anEntry);
	T result = removeEntry(i);
	return anEntry.equals(result);
	
}
	
}
