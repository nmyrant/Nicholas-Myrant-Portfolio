
public class BagDemo {
	
	public static void main(String[] args) {
		System.out.println("Testing an initially empty bag:");
		BagInterface<String> aBag = new ShoppingCart<>();
		String[] contentsOfBag1 = {"Double Cheeseburger", "Small Fries", "Large Coke", 
									"Chicken Sandwich", "Small Fries", "Ice Cream"};
		testAdd(aBag, contentsOfBag1);
		
		
		
		//testing remove() method removing last item and displaying
		aBag.remove();
		System.out.println("After a single call to the remove() method...");
		displayBag(aBag);
		
		//testing remove(anEntry) method removing Large Coke and displaying
		aBag.remove("Large Coke");
		System.out.println("After a single call to the remove(anEntry) method...");
		displayBag(aBag);
	}
	
	private static void testAdd(BagInterface<String> aBag, String[] content) {
		
		System.out.println("Adding the following food items to the bag: ");
		for (int i =0; i < content.length; i++) {
			if(aBag.add(content[i]))
				System.out.print(content[i] + ", ");	
			else
				System.out.print("\nUnable to add " + content[i] + " to the bag.");
		}
		System.out.println();
		displayBag(aBag);
	}

	private static void displayBag(BagInterface<String> aBag) {
		System.out.println("\nThe bag contains the following food item(s): ");
		Object[] bagArray = aBag.toArray();
		for (int i = 0; i <bagArray.length; i++) {
			System.out.println(bagArray[i] + " ");
		}
		System.out.println();
	}
}