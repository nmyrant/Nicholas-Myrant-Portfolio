
public class Cone extends Shape {
	private double radius;
	private double height;
	
	
	public Cone (double radius, double height) {
		this.radius = radius;
		this.height = height;
	}
	
	
	@Override  // Method for finding surface area of Cone
	public double surface_area(){ 												  						  
		return (Math.PI * radius * (radius + Math.sqrt(Math.pow(height, 2) + Math.pow(radius, 2))));
	}
	@Override  // Method for finding volume of Cone
	public double volume() {
		return (Math.PI * Math.pow(radius, 2) * (height / 3));
	}
	
	@Override  // Overrides "toString" method from Object class to 
               //print volume and surface area for Cone
	public String toString(){
	return "Cone Method \n" + "Surface area: " + surface_area() + 
			"\nVolume: " + volume() + "\n"; 
	}
}