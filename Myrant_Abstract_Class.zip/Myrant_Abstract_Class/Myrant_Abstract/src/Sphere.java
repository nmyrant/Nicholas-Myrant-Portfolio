
public class Sphere extends Shape {
	private double radius; 
	
	
	public Sphere(double radius) {
		this.radius = radius;
	}
	
	
	@Override  // Method for finding surface area of Sphere
	public double surface_area(){                       
		return (Math.PI * 4 * Math.pow(radius, 2));
	}
	@Override  // Method for finding volume of Sphere
	public double volume() {
		return ((4 * Math.PI * Math.pow(radius, 3) /3));
	}
	
	@Override  // Overrides "toString" method from Object class to 
	           //print volume and surface area for Sphere
	public String toString(){
	return "Sphere Method \n" + "Surface area: " + surface_area() + 
			"\nVolume: " + volume() + "\n";  
	}
}