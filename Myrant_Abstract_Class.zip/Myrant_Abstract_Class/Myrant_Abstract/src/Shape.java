
public abstract class Shape {

	abstract double surface_area();    // creating abstract method surface_area
	
	abstract double volume();	       // creating abstract method volume
}
