import java.util.ArrayList;

public class ShapeArray {

	public static void main(String[] args) {
		ArrayList<Shape> shapesList1 = new ArrayList<Shape>();   // Declares an ArrayList of type Shape
		
		Sphere sphere1 = new Sphere(5);                          // Creates an instance of a Sphere
		shapesList1.add(sphere1);							     // and loads it into the ArrayList			
		
		Cylinder cylinder1 = new Cylinder(4,4);				     // Creates an instance of a Cylinder
		shapesList1.add(cylinder1);							     // and loads it into the ArrayList	
		
		Cone cone1 = new Cone(6,6);								 // Creates an instance of a Cone
		shapesList1.add(cone1);								     // and loads it into the ArrayList	

		
		for (Shape shape : shapesList1) {                        // Loop to run through arrayList
			System.out.println(shape.toString());                // Calls Overridden "toString" method
		}	
	}
}