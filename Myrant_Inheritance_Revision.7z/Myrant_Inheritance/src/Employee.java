
public class Employee {
	public void setFirstName(String newFirstName){
		firstName = newFirstName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setLastName(String newLastName) {
		
		lastName = newLastName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setEid(int newEid) {
		eid = newEid;
	}
	public int getEid() {
		return eid;
	}
	
	public void setSalary(double newSalary) {
		
		salary = 0;
		salary = newSalary;
	}
	public void employeeSummary() {
		System.out.println("First name: " + firstName); 
		System.out.println("Last name: " + lastName);
		System.out.println("EID: " + eid);
		System.out.println("Salary: " + salary);		
	}
	   
	protected String firstName;
	protected String lastName;
	protected int eid;
	protected double salary;
}