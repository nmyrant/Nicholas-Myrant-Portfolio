

       	public class EmployeeInheritance{
			public static void main(String[] args) {
				 
				Employee Dan = new Employee();
				Manager Dave = new Manager();
				
				
				Dan.setFirstName("Dan");
				Dan.setLastName("Rogers");
				Dan.setEid(818469);
				Dan.setSalary(40000.0);
				Dan.employeeSummary();
				
				System.out.println("");
				
				Dave.setFirstName("Dave");
				Dave.setLastName("Smith");
				Dave.setEid(393109);
				Dave.setSalary(75000.0);
				Dave.setDepartment("Legal");
				Dave.employeeSummary();
				
				
			}	
			
		}  