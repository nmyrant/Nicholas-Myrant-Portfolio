public class BackwardArray {
	// Regular recursive method to display array
	public static void displayArray(int array[], int first, int last) {
		System.out.print(array[first] + " ");
		
		if (first < last) 
			displayArray(array, first + 1, last);
		
	}
	// Method to display array backwards 
	public static void reverse(int array[], int first, int last) {
		System.out.print(array[last] + " ");
		
		if (last > first) 
			reverse(array, first, last - 1);
		
	}

// Test method
public static void main(String[] args) {
	int array1[] = {1,2,3,4,5};
	
	System.out.println("Array in regular order: ");
	displayArray(array1, 0, 4);
	
	System.out.println("\nArray in backwards order: ");
	reverse(array1, 0, 4);
}
} 